const espIP = 'http://192.168.1.16/sensor'; // Replace with your ESP8266 IP
const historyAPI = 'get_data.php'; // Path to your history API endpoint

let chartInstance = null;
let historyChartInstance = null;
let activeSensor = 'humidity'; // Default chart sensor
let currentHistorySensor = null;
let chartData = {
    labels: [],
    humidity: [],
    temperature: [],
    ph: [],
    sodium: [],
    potassium: [],
    phosphorus: []
};

// Apply dark mode if previously enabled
document.addEventListener("DOMContentLoaded", () => {
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
    }
    setupHistoryButtons();
    setupChartToggle();
});

// Dark Mode Toggle
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem("darkMode", document.body.classList.contains('dark-mode') ? "enabled" : "disabled");
    
    // Update charts to reflect dark mode changes
    if (chartInstance) chartInstance.update();
    if (historyChartInstance) historyChartInstance.update();
}

// Initialize history buttons
function setupHistoryButtons() {
    document.querySelectorAll('.history-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent triggering the data-box click
            currentHistorySensor = this.dataset.sensor;
            document.getElementById('timeRangeSelector').style.display = 'block';
            // Hide live chart if showing
            document.getElementById('chartBox').style.display = 'none';
            if (chartInstance) {
                chartInstance.destroy();
                chartInstance = null;
            }
        });
    });
    
    document.getElementById('fetchHistory').addEventListener('click', fetchHistoricalData);
    document.getElementById('closeHistory').addEventListener('click', closeHistoryView);
}

// Setup toggle between live and history charts
function setupChartToggle() {
    document.querySelectorAll('.data-box').forEach(box => {
        box.addEventListener('click', function() {
            document.querySelectorAll('.data-box').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            showChart(this.dataset.sensor);
            // Hide history chart if showing
            document.getElementById('historyChartBox').style.display = 'none';
            if (historyChartInstance) {
                historyChartInstance.destroy();
                historyChartInstance = null;
            }
        });
    });
}

// Close history view
function closeHistoryView() {
    document.getElementById('timeRangeSelector').style.display = 'none';
    document.getElementById('historyChartBox').style.display = 'none';
    if (historyChartInstance) {
        historyChartInstance.destroy();
        historyChartInstance = null;
    }
}

// Fetch sensor data every 5 seconds
setInterval(fetchSensorData, 5000);
fetchSensorData();

// Function to fetch sensor data
async function fetchSensorData() {
    try {
        const response = await fetch(espIP);
        if (!response.ok) throw new Error(`HTTP Error! Status: ${response.status}`);

        const data = await response.json();
        let now = new Date().toLocaleTimeString();

        // Keep only last 10 values
        if (chartData.labels.length >= 10) {
            chartData.labels.shift();
            Object.keys(chartData).forEach(key => key !== "labels" && chartData[key].shift());
        }

        // Push new data
        chartData.labels.push(now);
        Object.keys(data).forEach(key => chartData[key]?.push(data[key]));

        // Update UI, gauges, and chart
        updateSensorUI(data);
        updateGauges(data);
        updateLiveChart();

        // Store the data in the database
        await storeSensorData(data);

        // Check for alerts
        checkAlerts(data, now);
    } catch (error) {
        console.error('Error fetching data:', error.message);
    }
}

// Function to store sensor data in the database
async function storeSensorData(data) {
    try {
        const response = await fetch('store_data.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data), // Send the sensor data as JSON
        });

        if (!response.ok) {
            throw new Error(`Error storing data: ${response.statusText}`);
        }
    } catch (error) {
        console.error('Error storing data:', error.message);
    }
}


// Fetch historical data
async function fetchHistoricalData() {
    const timeRange = document.getElementById('timeRange').value;
    try {
        const response = await fetch(`${historyAPI}?sensor=${currentHistorySensor}&hours=${timeRange}`);
        if (!response.ok) throw new Error(`HTTP Error! Status: ${response.status}`);
        
        const data = await response.json();
        if (data.error) throw new Error(data.error);
        
        drawHistoryChart(data);
    } catch (error) {
        console.error('Error fetching historical data:', error);
        alert('Failed to fetch historical data. Please try again.');
    }
}

// Draw history chart
function drawHistoryChart(data) {
    const ctx = document.getElementById('historyChart').getContext('2d');
    
    // Destroy previous chart if exists
    if (historyChartInstance) historyChartInstance.destroy();
    
    // Define color schemes for sensors
    const sensorColors = {
        humidity: 'rgba(0, 123, 255, 0.6)',
        temperature: 'rgba(255, 99, 132, 0.6)',
        ph: 'rgba(54, 162, 235, 0.6)',
        sodium: 'rgba(255, 206, 86, 0.6)',
        potassium: 'rgba(75, 192, 192, 0.6)',
        phosphorus: 'rgba(153, 102, 255, 0.6)'
    };
    
    historyChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(item => new Date(item.timestamp).toLocaleString()),
            datasets: [{
                label: currentHistorySensor.toUpperCase(),
                data: data.map(item => item.value),
                borderColor: sensorColors[currentHistorySensor],
                backgroundColor: sensorColors[currentHistorySensor].replace('0.6', '0.2'),
                fill: true,
                tension: 0.1,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: `${currentHistorySensor.toUpperCase()} History`,
                    font: { size: 16 },
                    color: document.body.classList.contains('dark-mode') ? '#eee' : '#666'
                },
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    title: { 
                        display: true, 
                        text: 'Time',
                        color: document.body.classList.contains('dark-mode') ? '#eee' : '#666'
                    },
                    ticks: {
                        color: document.body.classList.contains('dark-mode') ? '#eee' : '#666',
                        maxRotation: 45,
                        minRotation: 45
                    },
                    grid: {
                        color: document.body.classList.contains('dark-mode') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                    }
                },
                y: {
                    title: { 
                        display: true, 
                        text: 'Value',
                        color: document.body.classList.contains('dark-mode') ? '#eee' : '#666'
                    },
                    ticks: {
                        color: document.body.classList.contains('dark-mode') ? '#eee' : '#666'
                    },
                    grid: {
                        color: document.body.classList.contains('dark-mode') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                    }
                }
            }
        }
    });
    
    document.getElementById('historyChartBox').style.display = 'block';
}

// Function to update UI values
function updateSensorUI(data) {
    Object.keys(data).forEach(key => {
        let element = document.getElementById(`value-${key}`);
        if (element) element.textContent = formatSensorValue(key, data[key]);
    });
}

// Function to format sensor values for display
function formatSensorValue(sensor, value) {
    const units = {
        humidity: "%",
        temperature: "°C",
        sodium: " mg/L",
        potassium: " mg/L",
        phosphorus: " mg/L"
    };
    return value + (units[sensor] || "");
}

// Function to update gauge indicators
function updateGauges(data) {
    document.querySelectorAll(".gauge .fill").forEach(gauge => {
        const sensor = gauge.parentElement.parentElement.dataset.sensor;
        if (data[sensor] !== undefined) {
            let value = Math.min(Math.max(data[sensor], 0), 100); // Clamp between 0-100
            gauge.style.transform = `scaleY(${value/100})`;
        }
    });
}

// Function to show live chart
function showChart(sensorType) {
    activeSensor = sensorType;
    document.getElementById('chartBox').style.display = 'block';
    drawChart();
}

// Function to draw/update chart
function drawChart() {
    const ctx = document.getElementById('sensorChart').getContext('2d');

    // Destroy previous chart if exists
    if (chartInstance) chartInstance.destroy();

    // Define color schemes for sensors
    const sensorColors = {
        humidity: 'rgba(0, 123, 255, 0.6)',
        temperature: 'rgba(255, 99, 132, 0.6)',
        ph: 'rgba(54, 162, 235, 0.6)',
        sodium: 'rgba(255, 206, 86, 0.6)',
        potassium: 'rgba(75, 192, 192, 0.6)',
        phosphorus: 'rgba(153, 102, 255, 0.6)'
    };

    chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [{
                label: activeSensor.toUpperCase(),
                data: chartData[activeSensor],
                borderColor: sensorColors[activeSensor],
                backgroundColor: sensorColors[activeSensor].replace('0.6', '0.2'),
                fill: true,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: `${activeSensor.toUpperCase()} Live Data`,
                    font: { size: 16 },
                    color: document.body.classList.contains('dark-mode') ? '#eee' : '#666'
                },
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: document.body.classList.contains('dark-mode') ? '#eee' : '#666'
                    },
                    grid: {
                        color: document.body.classList.contains('dark-mode') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                    }
                },
                y: {
                    ticks: {
                        color: document.body.classList.contains('dark-mode') ? '#eee' : '#666'
                    },
                    grid: {
                        color: document.body.classList.contains('dark-mode') ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                    }
                }
            }
        }
    });
}

// Auto-update live chart
function updateLiveChart() {
    if (chartInstance) {
        chartInstance.data.labels = chartData.labels;
        chartInstance.data.datasets[0].data = chartData[activeSensor];
        chartInstance.update();
    }
}

// Function to check for alerts
function checkAlerts(data, time) {
    let alertTable = document.getElementById("alertTableBody");
    let existingAlerts = new Set([...alertTable.rows].map(row => row.cells[1].textContent));
    let alerts = [];

    if (data.humidity > 80 && !existingAlerts.has("Humidity")) alerts.push({ sensor: "Humidity", value: `${data.humidity}%`, message: "Too High!" });
    if (data.temperature > 35 && !existingAlerts.has("Temperature")) alerts.push({ sensor: "Temperature", value: `${data.temperature}°C`, message: "Overheating!" });
    if ((data.ph < 5 || data.ph > 8) && !existingAlerts.has("pH Level")) alerts.push({ sensor: "pH Level", value: data.ph, message: "Unstable pH!" });
    if (data.sodium > 50 && !existingAlerts.has("Sodium")) alerts.push({ sensor: "Sodium", value: `${data.sodium} mg/L`, message: "High Sodium!" });
    if (data.potassium > 50 && !existingAlerts.has("Potassium")) alerts.push({ sensor: "Potassium", value: `${data.potassium} mg/L`, message: "High Potassium!" });
    if (data.phosphorus > 50 && !existingAlerts.has("Phosphorus")) alerts.push({ sensor: "Phosphorus", value: `${data.phosphorus} mg/L`, message: "High Phosphorus!" });

    alerts.forEach(alert => {
        let row = `<tr><td>${time}</td><td>${alert.sensor}</td><td>${alert.value}</td><td>${alert.message}</td></tr>`;
        alertTable.innerHTML += row;
    });

    if (alertTable.rows.length > 10) alertTable.deleteRow(0);
}

// Function to clear all alerts
function clearAllAlerts() {
    document.getElementById("alertTableBody").innerHTML = "";
}

// Attach event listener to the "Clear All" button
document.addEventListener("DOMContentLoaded", function() {
    let clearButton = document.getElementById("clearAllButton");
    if (clearButton) {
        clearButton.addEventListener("click", clearAllAlerts);
    }
});